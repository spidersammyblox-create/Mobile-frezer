/* newlib 1.8.2 libc/stdio/printf.c (_printf_r was dead-stripped) */
#include "newlib_stdio.h"

/* Reentrant printf: formats into the reent's stdout. */
int _printf_r(struct _reent *ptr, const char *fmt, ...)
{
    int ret;
    va_list ap;

    va_start(ap, fmt);
    ret = _vfprintf_r(ptr, _stdout_r(ptr), fmt, ap);
    va_end(ap);
    return ret;
}

/* printf onto stdout (the game's OSReport-backed FILE). */
int printf(const char *fmt, ...)
{
    int ret;
    va_list ap;

    va_start(ap, fmt);
    _stdout_r(_REENT)->_data = _REENT;
    ret = vfprintf(_stdout_r(_REENT), fmt, ap);
    va_end(ap);
    return ret;
}
